const { request, response } = require("express")
const productModel = require("../model/productModel")
const { v4 } = require("uuid")



const createController = async (request,response) => {
  try {
    const uuid = v4();
    const { productId, productName, price,quantity, productDesc} = request.body;

    const product = await productModel.create({
      productId:uuid,
       productName: productName,
       price:price,
       quantity:quantity,
       productDesc: productDesc
   });
   if (product && product._id) {
       response.status(201).json({ message: "Product entered successfully" });
     } else {
       response.status(404).json({ message: "Product not entered" });
     }
} catch (error) {
   response.status(500).json({ message: "Internal Server Error" });
}
}


const getController= async (request, response) => {
  try {
    const price = request.params.price;
    console.log(price);
    const product = await productModel.find({ price: price })

    if (product) {
      response.status(201).json({ message: "product found!" })
    } else {
      response.status(404).json({ message: "product Not found " })
    }
  } catch (error) {
    response.status(500).json({ message: "Internal Server error" })
  }
}



const deleteController = async (request, response) => {
    try {
      const productName = request.params.productName;
      console.log(productName);
      const product = await productModel.deleteOne({ productName: productName })
      console.log(product);
  
      if (product) {
        response.status(201).json({ message: "product deleted Successfully" })
      } else {
        response.status(404).json({ message: "product Not deleted " })
      }
    } catch (error) {
      response.status(500).json({ message: "Internal Server error" })
    }
 }


const updateController = async (request, response) => {
  try {
    const productName = request.params.productName;
    
    // Update the product's quantity using findOneAndUpdate and $inc operator
    const product = await productModel.findOneAndUpdate(
      { productName: productName },
      { $inc: { quantity: 1 } },
      { new: true }
    );

    if (product) {
      response.status(200).json({ message: "Product quantity incremented successfully", product: product });
    } else {
      response.status(404).json({ message: "Product not found" });
    }
  } catch (error) {
    console.error(error);
    response.status(500).json({ message: "Internal Server Error" });
  }
};





module.exports = {createController,getController,deleteController,updateController}