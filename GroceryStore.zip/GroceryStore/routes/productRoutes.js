const { Router } = require("express");
const {
  getController,
  createController,
  deleteController,
  updateController
} = require("../controllers/productController");

const productRoutes = Router();

productRoutes.get("/get/:price", (request, response) => {
  getController(request, response);
});

productRoutes.post("/create", (request, response) => {
  createController(request, response);
});
productRoutes.delete("/delete/:productName", (request, response) => {
  deleteController(request, response);
});
productRoutes.put("/increment/:productName", (request, response) => {
  updateController(request, response);
});
module.exports = productRoutes;
