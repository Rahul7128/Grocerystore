const { default: mongoose } = require("mongoose")

const URL ="mongodb+srv://rahulsangwaan02:rahul21csu360@cluster0.urhw5ij.mongodb.net/?retryWrites=true&w=majority "
const connection = ()=>{
    mongoose.connect(URL).then(()=>{
        console.log("Database Connected Successfully");
    }).catch(()=>{
        console.log("Database Not Connected");
    })
}

module.exports = connection;